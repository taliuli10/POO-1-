/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.atividade_teste;

import java.util.Random;
import java.time.Year;

/**
 *
 * @author alunolab11
 */
public class Atividade_teste {

    public static void main(String[] args) {
        System.out.println("Hello World!");

    }
}