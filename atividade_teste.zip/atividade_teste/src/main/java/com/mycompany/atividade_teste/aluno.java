/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.atividade_teste;

import java.time.Year;
import java.util.Random;

/**
 *
 * @author alunolab11
 */
public class aluno {
    private String matricula = gerarMatricula();
    private String nome;
    private String curso;
    private String turma;
    private int periodo;
    private double nota1b;
    private double nota2b;
    private double notaFinal;
    private static int quantidadeAlunos = 0;
    
    public void imprimir() {
        System.out.println("Matrícula: " + matricula);
        System.out.println("Nome: " + nome);
        System.out.println("Curso: " + curso);
        System.out.println("Turma: " + turma);
        System.out.println("Período: " + periodo);
        System.out.println("Nota 1B: " + nota1B);
        System.out.println("Nota 2B: " + nota2B);
        System.out.println("Nota Final: " + notaFinal);
    }

    public aluno(String matricula, String nome, String curso, String turma, int periodo, double nota1b, double nota2b ){
        this.nome = nome.toUpperCase();
        this.curso = curso;
        this.turma = turma;
        this.periodo = periodo;
        this.nota1b = nota1b;
        this.nota2b = nota2b;
        this.notaFinal = calcularNotaFinal();
        notaFinal++;
        
    }
    
    private double calcularNotaFinal() {
        return (this.nota1b + this.nota2b) / 2;
    }
    
    public String getMatricula(){
        return matricula;
    }
    
    public void setMatricula(String matricula){
        this.matricula = matricula;
    }

    private String gerarMatricula() {
        int AnoAtual = Year.new().getValue();
        Random random = new Random();
        int ramdom = random.nextInt(1000); 
        String matricula = AnoAtual + "-" + String .format("%04d", random);
        return matricula;
    }
        
        
    
}



