/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exerciciocolecoesmapas;

import java.util.ArrayList;

/**
 *
 * @author alunolab08
 */
public class agendaTelefonica {
    private ArrayList <Contato> contatos;
    
    public agendaTelefonica(){
        contatos = new ArrayList<>();
    }
    
    public void inserir(String nome, String numero){
        Contato novoContato = new Contato(nome, numero);
        contatos.add(novoContato);
    }
    
    public String buscarNumero(String nome){
        for (Contato c : contatos){
            if(c.getNome().equals(nome)){
                return c.getNumero();
            }
        }
        return null;
    }
    
    public void remover(String nome){
        contatos.removeIf(c -> c.getNome().equals(nome));
    }
    
    public int tamanho(){
        return contatos.size();
    }
}
