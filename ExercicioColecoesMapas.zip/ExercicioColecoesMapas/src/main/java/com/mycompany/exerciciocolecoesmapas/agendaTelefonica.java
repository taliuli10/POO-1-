/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exerciciocolecoesmapas;

import java.util.HashMap;
import java.util.Map;

public class agendaTelefonica {
    private Map<String, Contato> contatos;

    public agendaTelefonica() {
        contatos = new HashMap<>();
    }

    // Inserir um contato
    public void inserir(Contato contato) {
        contatos.put(contato.getNome(), contato);
    }

    // Buscar o número de um contato pelo nome
    public String buscarNumero(String nome) {
        Contato contato = contatos.get(nome);
        return (contato != null) ? contato.getNumero() : null;
    }

    // Remover um contato
    public void remover(String nome) {
        contatos.remove(nome);
    }

    // Retornar o tamanho da agenda
    public int tamanho() {
        return contatos.size();
    }
}

