/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.exerciciocolecoesmapas;

/**
 *
 * @author alunolab08
 */
public class ExercicioColecoesMapas {
    
    public static void main(String[] args) {
        agendaTelefonica agenda = new agendaTelefonica();
        
        agenda.inserir(new Contato("Ricardo", "9999-43534"));
        agenda.inserir(new Contato("Davi", "9993-57584"));
        agenda.inserir(new Contato("Miguel", "9998-42514"));
        agenda.inserir(new Contato("Vitor", "9998-19043"));
        agenda.inserir(new Contato("Felipe", "9998-06184"));
        
        System.out.println("Tamanho da agenda: " + agenda.tamanho());
        
        System.out.println("Numero Ricardo: " + agenda.buscarNumero("Ricardo"));
        System.out.println("Numero de Davi: " + agenda.buscarNumero("Davi"));
        
        agenda.remover("Miguel");
        
        System.out.println("Tamanho da agenda após remover alguém: " + agenda.tamanho());
    }
}
