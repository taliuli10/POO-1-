/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.exerciciocolecoesmapas;

/**
 *
 * @author alunolab08
 */
public class ExercicioColecoesMapas {

    public static void main(String[] args) {
        agendaTelefonica agenda = new agendaTelefonica();
        
        agenda.inserir("Ricardo", "9999-43534");
        agenda.inserir("Davi", "9993-57584");
        agenda.inserir("Miguel", "9998-42514");
        agenda.inserir("Vitor", "9998-19043");
        agenda.inserir("Felipe", "9998-06184");
        
        System.out.println("Tamanho da agenda: " + agenda.tamanho());
        
        System.out.println("Numero Ricardo: " + agenda.buscarNumero("Ricardo"));
        System.out.println("Numero de Davi: " + agenda.buscarNumero("Davi"));
        
        agenda.remover("Miguel");
        
        System.out.println("Tamanho da agenda apos remover alguem: " + agenda.tamanho());
    }
    
}
