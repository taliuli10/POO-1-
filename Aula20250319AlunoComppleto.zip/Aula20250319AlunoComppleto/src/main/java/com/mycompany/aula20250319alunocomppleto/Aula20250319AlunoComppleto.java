package com.mycompany.aula20250319alunocomppleto;

public class Aula20250319AlunoComppleto {

    public static void main(String[] args) {
        System.out.println("ALUNO");
        
        Aluno a1 = new Aluno();
        a1.setNome("Cassio");
        //System.out.println("Matricula: "+ a1.getMatricula());
        a1.imprimir();
        System.out.println(a1);
    }
}
